# market-ru-seo

SEO-аудит сайта для Google и Яндекс. Автоматический анализ + подробные отчёты.

## Что делает этот скилл

Проводит SEO-аудит любого сайта и показывает:
- Насколько сайт оптимизирован для поиска в Google
- Насколько сайт оптимизирован для поиска в Яндекс
- Какие конкретно проблемы нужно исправить
- В каком порядке лучше всего исправлять

## Как это работает

### Шаг 1: Анализ

Скрипт сканирует сайт и проверяет 16 факторов (8 для Google + 8 для Яндекс).

### Шаг 2: Оценка

Каждый фактор получает баллы. Чем больше баллов — тем лучше:
- **0-7** — плохо, нужно срочно исправить
- **8-13** — требует работы
- **14-20** — хорошо

### Шаг 3: Отчёт

Генерируются два отчёта:
- **Markdown** — подробный текстовый анализ
- **HTML** — красивая страница с визуализацией

## Почему Google и Яндекс оцениваются по-разному

Google и Яндекс — разные поисковые системы. Они учитывают разные факторы:

| Для Google важнее | Для Яндекс важнее |
|-------------------|-------------------|
| Ссылки на сайт | Коммерческие данные (телефоны, адреса) |
| Качество контента | Поведение пользователей |
| Техническая оптимизация | Яндекс.Метрика и Вебмастер |

Поэтому скилл проверяет разные вещи для каждой системы и выводит **2 отдельные оценки**.

Для сайтов в России: Яндекс важнее (70%), Google (30%).

## Установка

### OpenCode

```bash
npm install -g market-ru-seo
```

После установки добавь плагин в `opencode.json`:

```json
{
  "plugin": [
    "...existing plugins...",
    "market-ru-seo"
  ]
}
```

Или используй путь к глобальному npm:

```json
{
  "plugin": [
    "...existing plugins...",
    "ПУТЬ_К_NPM/node_modules/market-ru-seo/.opencode/plugins/market-ru-seo.js"
  ]
}
```

Найти путь: `npm root -g`

### Claude Code

```bash
curl -fsSL https://raw.githubusercontent.com/Valdiss-Valdiss/ai-marketing-ru-seo/main/install.sh | bash
```

Или вручную:

```bash
git clone https://github.com/Valdiss-Valdiss/ai-marketing-ru-seo.git
cd ai-marketing-ru-seo
./install.sh
```

## Использование

```
/market-ru-seo <url>
```

### Пример

```
/market-ru-seo https://example.com
```

## Скрипты

| Скрипт | Назначение |
|--------|------------|
| `scripts/analyze_page.py` | Сканирует сайт и собирает данные |
| `scripts/generate_seo_md.py` | Создаёт Markdown-отчёт |
| `scripts/generate_seo_html.py` | Создаёт HTML-страницу |

Запуск вручную:

```bash
python3 scripts/analyze_page.py <url>
python3 scripts/generate_seo_md.py <url>
python3 scripts/generate_seo_html.py <url>
```

## Требования

- Python 3.x
- OpenCode или Claude Code

## Для AI-агентов

Если ты AI-агент и хочешь установить этот скилл:

1. Прочитай файл `AGENT_INSTALL.md` в этом репозитории
2. Следуй инструкциям по установке для твоей IDE

## Примеры отчётов

См. папку `examples/`:
- `example-seo-audit.md`
- `example-seo-audit.html`

## Лицензия

MIT License